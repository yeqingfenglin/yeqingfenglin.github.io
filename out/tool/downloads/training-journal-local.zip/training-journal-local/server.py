from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
import argparse
import mimetypes
mimetypes.add_type("text/javascript", ".mjs")
parser = argparse.ArgumentParser(description="Local training journal")
parser.add_argument("--port", type=int, default=8765)
args = parser.parse_args()
handler = partial(SimpleHTTPRequestHandler, directory=str(Path(__file__).resolve().parent))
print(f"Open http://127.0.0.1:{args.port} in your browser. Ctrl+C to stop.", flush=True)
try:
    ThreadingHTTPServer(("127.0.0.1", args.port), handler).serve_forever()
except KeyboardInterrupt:
    pass
