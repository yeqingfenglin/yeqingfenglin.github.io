@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 请打开 http://127.0.0.1:8765 ，保持此窗口运行。
where py >nul 2>nul
if errorlevel 1 (python server.py) else (py -3 server.py)
pause
