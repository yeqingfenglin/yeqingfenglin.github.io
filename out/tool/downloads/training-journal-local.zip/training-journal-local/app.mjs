import {PEOPLE,EXERCISES,THEMES,validateOperation,materialize,occurs,personalBests,normalizeBackup} from './core.mjs';
const $=id=>document.getElementById(id), local=window.FITNESS_LOCAL===true;
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dateString=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const today=dateString(new Date());
let date=today,month=new Date(new Date().getFullYear(),new Date().getMonth(),1),person='dengjie',viewer='dengjie';
let operations=new Map(),records=[],known=new Set(),client,user,busy=false,syncing=false,active=true,editing=null,historyLimit=60;
let preferenceTimer,preferenceDirty=false,preferenceSerial=0,preferenceSaving=false,localDB;
const status=(message,error=false)=>{$('status').textContent=message;$('status').classList.toggle('error',error);};
const currentRecords=kind=>records.filter(r=>!r.current.deleted&&!r.conflict&&r.current.kind===kind&&r.current.value.person===person);
const getRecord=id=>records.find(r=>r.id===id);
const settingsId=p=>p==='dengjie'?'00000000-0000-4000-8000-000000000001':'00000000-0000-4000-8000-000000000002';
function applyPreferences(theme,font){const palette=THEMES[theme]||THEMES[0];['--bg','--paper','--ink','--accent'].forEach((key,i)=>document.documentElement.style.setProperty(key,palette[i+1]));document.documentElement.style.fontSize=font+'px';document.documentElement.style.colorScheme=theme>=8?'dark':'light';$('theme').value=theme;$('font').value=font;$('font-value').value=font;}
function rebuild(){records=materialize([...operations.values()]);if(!preferenceDirty){const setting=getRecord(settingsId(viewer));if(setting&&!setting.current.deleted)applyPreferences(setting.current.value.theme,setting.current.value.font);}render();}
async function gateway(action,payload={}) {
 const {data:{session}}=await client.auth.getSession();
 if(!session) {lock('登录已失效，请返回内板重新登录。');throw Error('登录已失效');}
 const {data,error}=await client.functions.invoke(window.SITE_CONTENT_CONFIG?.gatewayFunction||'cos-content',{body:{action,...payload},headers:{Authorization:'Bearer '+session.access_token}});
 if(error){let message=error.message;try{message=(await error.context.json()).error||message;}catch{}throw Error(message);}
 if(data?.error)throw Error(data.error);return data;
}
function lock(message){active=false;operations.clear();records=[];$('app').hidden=true;$('gate').hidden=false;$('gate').textContent=message;document.querySelectorAll('#logs,#best-list,#history-list,#plans,#conflicts,#fields').forEach(x=>x.replaceChildren());if($('editor').open)$('editor').close();}
async function checkAdmin(){const {data,error}=await client.from('profiles').select('username,role,status').eq('id',user.id).single();if(error||data?.role!=='admin'||data?.status!=='approved'){lock('仅已获准的管理员可查看。请返回内板登录。');throw Error('管理员身份验证失败');}return data;}
async function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open('training-journal-local',1);req.onupgradeneeded=()=>req.result.createObjectStore('operations',{keyPath:'id'});req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(Error('无法打开本地储存，请检查浏览器设置'));});}
async function dbRead(){return new Promise((resolve,reject)=>{const req=localDB.transaction('operations').objectStore('operations').getAll();req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
async function dbWrite(items){return new Promise((resolve,reject)=>{const tx=localDB.transaction('operations','readwrite');for(const item of items)tx.objectStore('operations').put(item);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('本地储存失败'));});}
async function sync(){
 if(syncing||!active)return;syncing=true;
 try{
  if(local){for(const op of await dbRead())operations.set(op.id,op);}
  else{
   await checkAdmin();let marker='';
   do{const page=await gateway('fitness-list',{marker});if(!active)return;const missing=page.keys.filter(key=>!known.has(key));for(let i=0;i<missing.length;i+=50){const keys=missing.slice(i,i+50),data=await gateway('fitness-read',{keys});if(!active)return;for(const op of data.operations)operations.set(op.id,op);keys.forEach(key=>known.add(key));}marker=page.marker;}while(marker);
  }
  rebuild();status(preferenceDirty?'配色或字号尚未保存，请点击同步重试':`${local?'已储存到本机':'COS 已同步'} · ${new Date().toLocaleTimeString('zh-CN')}`);
 }catch(error){status('同步失败：'+error.message+'。未保存的编辑仍保留，请重试。',true);}finally{syncing=false;}
}
async function append(kind,value,entity=crypto.randomUUID(),parents=[],deleted=false,id=crypto.randomUUID()){
 const operation=validateOperation({id,entity,kind,parents,deleted,value});let saved;
 if(local){saved={...operation,actor:PEOPLE[viewer],at:new Date().toISOString()};await dbWrite([saved]);}
 else {const result=await gateway('fitness-append',{operation});saved=result.operation;known.add(result.key);}
 if(!active)throw Error('登录已失效');operations.set(saved.id,saved);rebuild();status(local?'已保存到本机':'已保存到 COS');return saved;
}
function switchTab(id){document.querySelectorAll('.panel').forEach(x=>x.hidden=x.id!==id);document.querySelectorAll('[data-tab]').forEach(x=>x.setAttribute('aria-selected',String(x.dataset.tab===id)));}
function selectDate(value){date=value;$('day').value=date;render();}
function description(op){const v=op.value;return `${PEOPLE[v.person]} · ${v.title||v.exercise||v.name||(op.kind==='settings'?'显示设置':'记录')}${v.date?' · '+v.date:''}${op.deleted?' · 已删除':''}`;}
function actionButton(text,action,id){return `<button data-action="${action}" data-id="${id}">${text}</button>`;}
function render(){
 $('month-title').textContent=`${month.getFullYear()}年 ${month.getMonth()+1}月`;$('selected-label').textContent=date+' · 训练计划';
 const plans=currentRecords('plan'),logs=currentRecords('log');
 const offset=(new Date(month.getFullYear(),month.getMonth(),1).getDay()+6)%7,total=new Date(month.getFullYear(),month.getMonth()+1,0).getDate();
 let html='<div class="day-blank" aria-hidden="true"></div>'.repeat(offset);
 for(let d=1;d<=total;d++){const key=dateString(new Date(month.getFullYear(),month.getMonth(),d)),items=plans.filter(r=>occurs(r.current.value,key)),count=logs.filter(r=>r.current.value.date===key).length;html+=`<button class="day-cell ${key===date?'selected':''} ${key===today?'is-today':''}" data-date="${key}" aria-label="${key}，${items.length}项计划，${count}项训练" aria-pressed="${key===date}"><span class="day-number">${d}</span>${items.slice(0,2).map(r=>`<span class="plan-chip">${esc(r.current.value.title)}</span>`).join('')}${items.length>2?`<span class="plan-chip">+${items.length-2} 项</span>`:''}${count?`<span class="log-dot">● ${count} 项记录</span>`:''}</button>`;}
 $('month-grid').innerHTML=html;
 $('plans').innerHTML=plans.filter(r=>occurs(r.current.value,date)).map(r=>`<div class="record"><div><strong>${esc(r.current.value.title)}</strong><small>${r.current.value.interval?'每隔 '+r.current.value.interval+' 天 · 从 '+r.current.value.date+' 至 '+(r.current.value.end||'长期'):'仅当天'}</small></div><div class="row">${actionButton('编辑','edit',r.id)}${actionButton('删除'+(r.current.value.interval?'整个系列':''),'delete',r.id)}</div></div>`).join('')||'<div class="empty">给今天安排一点运动吧。</div>';
 $('logs').innerHTML=logs.filter(r=>r.current.value.date===date).map(r=>{const v=r.current.value;return `<tr><td>${esc(v.category)}</td><td><strong>${esc(v.exercise)}</strong></td><td>${v.sets}</td><td>${v.reps}</td><td>${v.weight} ${v.unit}</td><td>${actionButton('编辑','edit',r.id)} ${actionButton('删除','delete',r.id)}</td></tr>`;}).join('')||'<tr><td colspan="6" class="empty">还没有训练记录。完成一组，就是新的开始。</td></tr>';
 $('best-list').innerHTML=personalBests(records,person).map(v=>`<article class="best-card"><small>${esc(v.category)} · ${v.manual?'手动修正':'自动记录'}</small><h3>${esc(v.exercise)}</h3><div class="best-number">${v.weight} <small>${v.unit}</small></div><p>${v.reps} 次 · ${v.date}</p><button data-best="${esc(v.category+' / '+v.exercise)}">修正成绩</button>${v.manual?' '+actionButton('恢复自动','delete',v.entity):''}</article>`).join('')||'<div class="empty">添加训练后，你的个人最佳会出现在这里。</div>';
 const conflicts=records.filter(r=>r.conflict);$('conflicts').hidden=!conflicts.length;
 $('conflicts').innerHTML=conflicts.length?`<strong>${conflicts.length} 条记录有同时编辑的版本</strong><p>两个版本都已保留。核对后选择采用的版本；也可先导出备份。</p>`+conflicts.map(r=>`<div class="conflict-item">${r.heads.map(op=>`<div><strong>${esc(op.actor)} · ${esc(description(op))}</strong><pre>${esc(JSON.stringify(op.value,null,2))}</pre><button data-resolve="${op.id}" data-entity="${r.id}">采用此版本${op.deleted?'（删除）':''}</button></div>`).join('')}</div>`).join(''):'';
 const history=[...operations.values()].sort((a,b)=>(b.at||'').localeCompare(a.at||'')||b.id.localeCompare(a.id));
 $('history-list').innerHTML=history.slice(0,historyLimit).map(op=>`<div class="record"><div><strong>${esc(description(op))}</strong><small>${esc(op.actor)} · ${esc(op.at?new Date(op.at).toLocaleString('zh-CN'):'导入记录')}</small><details><summary>查看内容</summary><pre>${esc(JSON.stringify(op.value,null,2))}</pre></details></div>${actionButton('恢复此内容','restore',op.id)}</div>`).join('')||'<div class="empty">还没有修改历史。</div>';
 $('more-history').hidden=history.length<=historyLimit;
}
function field(name,label,type,value,extra=''){return `<label>${label}<input name="${name}" type="${type}" value="${esc(value)}" ${extra}></label>`;}
function choices(name,label,values,value){return `<label>${label}<select name="${name}">${values.map(x=>`<option value="${esc(x)}" ${x===value?'selected':''}>${esc(x)}</option>`).join('')}</select></label>`;}
function exerciseOptions(category,selected=''){
 const all=[...new Set([...(EXERCISES[category]||[]),...records.filter(r=>!r.conflict&&!r.current.deleted&&r.current.kind==='exercise'&&r.current.value.category===category).map(r=>r.current.value.name),...(selected?[selected]:[])])];
 return all.map(name=>`<option ${name===selected?'selected':''}>${esc(name)}</option>`).join('');
}
function openEditor(kind,record=null,initial=null){
 const value=initial||record?.current.value||{person,date,title:'',interval:0,end:'',category:'胸部',exercise:'杠铃卧推',sets:3,reps:10,weight:0,unit:'kg',name:''};
 editing={kind,entity:record?.id||crypto.randomUUID(),parents:record?.heads.map(x=>x.id)||[],person:value.person,id:crypto.randomUUID(),bases:new Map(records.map(r=>[r.id,r.heads.map(x=>x.id)]))};
 $('dialog-title').textContent=({plan:'训练计划',log:'训练动作',exercise:'自定义动作',best:'修正个人最佳',settings:'显示设置'})[kind];
 let html=`<p class="wide muted">记录所属人：${PEOPLE[value.person]}</p>`;
 if(kind==='plan')html+=field('title','训练项目','text',value.title,'required maxlength="200"')+field('date','开始日期','date',value.date,'required')+field('interval','每隔多少天一次（0 = 仅当天）','number',value.interval,'min="0" max="3650" step="1" required')+field('end','结束日期（可不填）','date',value.end||'')+'<p class="wide muted">例如每隔 2 天：9 月 1 日、3 日、5 日。编辑会修改整个重复系列。</p>';
 else if(kind==='settings')html+=field('font','字号','number',value.font,'min="14" max="22" required')+field('theme','配色编号 0–9','number',value.theme,'min="0" max="9" required');
 else {
  html+=choices('category','身体部位',Object.keys(EXERCISES),value.category);
  if(kind==='exercise')html+=field('name','新动作名称','text',value.name,'required maxlength="100"');
  else {html+=`<label>动作名称<select name="exercise">${exerciseOptions(value.category,value.exercise)}</select></label>`+field('date','日期','date',value.date,'required');if(kind==='log')html+=field('sets','组数','number',value.sets,'min="1" max="1000" step="1" required');html+=field('reps','每组次数','number',value.reps,'min="1" max="10000" step="1" required')+field('weight','重量','number',value.weight,'min="0" max="5000" step="0.01" required')+choices('unit','重量单位',['kg','lb'],value.unit);}
 }
 $('fields').innerHTML=html;$('form-error').textContent='';$('editor').showModal();
 const category=$('edit-form').elements.category;if(category&&kind!=='exercise')category.onchange=()=>{$('edit-form').elements.exercise.innerHTML=exerciseOptions(category.value);};
}
async function submit(event){event.preventDefault();if(busy)return;busy=true;$('save').disabled=true;$('form-error').textContent='';
 try{const values=Object.fromEntries(new FormData($('edit-form')));values.person=editing.person;for(const key of ['interval','sets','reps','weight','font','theme'])if(key in values)values[key]=Number(values[key]);
  if(editing.kind==='best'){
   const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify([values.person,values.category,values.exercise])));
   const hex=[...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
   editing.entity=`${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20,32)}`;
   editing.parents=editing.bases.get(editing.entity)||[];
  }
  const payload=JSON.stringify(values);if(editing.lastPayload&&editing.lastPayload!==payload)editing.id=crypto.randomUUID();editing.lastPayload=payload;
  await append(editing.kind,values,editing.entity,editing.parents,false,editing.id);$('editor').close();await sync();
 }catch(error){$('form-error').textContent=error.message+'；内容仍保留，可重试。';}finally{busy=false;$('save').disabled=false;}
}
async function mutateButton(button,task){if(busy)return;busy=true;button.disabled=true;try{await task();await sync();}catch(error){status(error.message,true);}finally{busy=false;button.disabled=false;}}
async function savePreferences(){
 if(!preferenceDirty||!active||preferenceSaving)return;const serial=preferenceSerial;preferenceSaving=true;
 const value={person:viewer,theme:Number($('theme').value),font:Number($('font').value)};const record=getRecord(settingsId(viewer));
 try{await append('settings',value,settingsId(viewer),record?.heads.map(x=>x.id)||[]);if(serial===preferenceSerial)preferenceDirty=false;}catch(error){status('显示设置尚未保存：'+error.message+'；点击同步重试。',true);}finally{preferenceSaving=false;if(serial!==preferenceSerial)savePreferences();}
}
function exportBackup(){const blob=new Blob([JSON.stringify({format:'training-journal',version:1,operations:[...operations.values()]},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='training-journal-'+today+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function initialize(){
 try{
  $('theme').innerHTML=THEMES.map((t,i)=>`<option value="${i}">${t[0]}</option>`).join('');$('day').value=date;
  if(local){localDB=await openDB();$('gate').textContent='正在读取本地记录…';$('back').textContent='运动记录本 · 本地版';$('back').removeAttribute('href');$('mode-label').textContent='数据保存在当前浏览器 · 请定期导出备份';$('import-label').hidden=false;}
  else {if(!window.supabase||!window.SITE_SUPABASE_CONFIG)throw Error('登录组件未加载，请检查网络并刷新');const cfg=window.SITE_SUPABASE_CONFIG;client=window.supabase.createClient(cfg.url,cfg.publishableKey);const {data:{session}}=await client.auth.getSession();if(!session)throw Error('请先返回内板登录管理员账号');user=session.user;const profile=await checkAdmin();viewer=profile.username.normalize('NFKC').trim().toLowerCase()==='lena11'?'wangboning':'dengjie';person=viewer;$('person').value=person;client.auth.onAuthStateChange((event)=>{if(event==='SIGNED_OUT')lock('你已退出登录。请返回内板重新登录。');});}
  $('gate').hidden=true;$('app').hidden=false;render();await sync();setInterval(()=>{if(!document.hidden)sync();},10000);
 }catch(error){lock(error.message);const link=document.createElement('a');link.href='../';link.textContent=' 返回内板';$('gate').appendChild(link);}
}
document.querySelectorAll('[data-tab]').forEach(button=>button.onclick=()=>switchTab(button.dataset.tab));
$('prev').onclick=()=>{month=new Date(month.getFullYear(),month.getMonth()-1,1);render();};$('next').onclick=()=>{month=new Date(month.getFullYear(),month.getMonth()+1,1);render();};$('today').onclick=()=>{month=new Date(new Date().getFullYear(),new Date().getMonth(),1);selectDate(today);};
$('person').onchange=()=>{person=$('person').value;rebuild();};$('day').onchange=()=>{if($('day').value)selectDate($('day').value);};
$('open-daily').onclick=()=>switchTab('daily');$('add-plan').onclick=()=>openEditor('plan');$('add-log').onclick=()=>openEditor('log');$('add-exercise').onclick=()=>openEditor('exercise');$('add-best').onclick=()=>openEditor('best');
$('close-dialog').onclick=$('cancel').onclick=()=>{if(!busy)$('editor').close();};$('editor').addEventListener('cancel',event=>{if(busy)event.preventDefault();});$('edit-form').onsubmit=submit;
$('refresh').onclick=async()=>{await savePreferences();await sync();};$('export').onclick=exportBackup;
for(const id of ['theme','font'])$(id).oninput=()=>{preferenceDirty=true;preferenceSerial++;applyPreferences(Number($('theme').value),Number($('font').value));clearTimeout(preferenceTimer);preferenceTimer=setTimeout(savePreferences,700);};
$('more-history').onclick=()=>{historyLimit+=60;render();};
document.addEventListener('click',event=>{
 const button=event.target.closest('button');if(!button)return;
 if(button.dataset.date)selectDate(button.dataset.date);
 if(button.dataset.best){const v=personalBests(records,person).find(v=>v.category+' / '+v.exercise===button.dataset.best);openEditor('best',v.entity?getRecord(v.entity):null,v);}
 if(button.dataset.action){const action=button.dataset.action;
  if(action==='edit')openEditor(getRecord(button.dataset.id).current.kind,getRecord(button.dataset.id));
  if(action==='delete'){const r=getRecord(button.dataset.id);if(confirm(r.current.kind==='best'?'取消手动修正，恢复自动计算？':'删除此记录？重复计划将删除整个系列，历史仍保留。'))mutateButton(button,()=>append(r.current.kind,r.current.value,r.id,r.heads.map(x=>x.id),true));}
  if(action==='restore'){const op=operations.get(button.dataset.id);if(confirm('将此历史内容恢复为新版本？')){const r=getRecord(op.entity);mutateButton(button,()=>append(op.kind,op.value,op.entity,r.heads.map(x=>x.id),false));}}
 }
 if(button.dataset.resolve){const r=getRecord(button.dataset.entity),op=operations.get(button.dataset.resolve);mutateButton(button,()=>append(op.kind,op.value,r.id,r.heads.map(x=>x.id),op.deleted));}
});
$('import').onchange=async()=>{const file=$('import').files[0];if(!file)return;try{if(file.size>20*1024*1024)throw Error('备份不能超过 20 MB');const data=JSON.parse(await file.text());const items=normalizeBackup(data,[...operations.values()]);await dbWrite(items);await sync();status('备份已合并导入');}catch(error){status('导入失败：'+error.message,true);}finally{$('import').value='';}};
window.addEventListener('beforeunload',event=>{if(busy||preferenceDirty||$('editor').open){event.preventDefault();event.returnValue='';}});
initialize();
